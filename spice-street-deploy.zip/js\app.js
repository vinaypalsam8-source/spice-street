// Spice Street - Main Application Coordinator
// UI Interactions, Menu Rendering, Search, Modals, Payment Orchestration

let activeCategory = "all";
let activeDietFilter = "all"; // 'all', 'veg', 'non-veg'
let searchQuery = "";

document.addEventListener("DOMContentLoaded", () => {
  initApp();
});

function initApp() {
  renderCategoryPills();
  renderMenuCards();
  initSearch();
  initDietaryFilters();
  initCartSubscription();
  initNavigation();
}

// Category Pills Rendering
function renderCategoryPills() {
  const container = document.getElementById("category-pills-container");
  if (!container) return;

  container.innerHTML = CATEGORIES.map(cat => `
    <button class="category-pill ${cat.id === activeCategory ? 'active' : ''}" onclick="selectCategory('${cat.id}')">
      ${cat.name}
    </button>
  `).join("");
}

function selectCategory(categoryId) {
  activeCategory = categoryId;
  renderCategoryPills();
  renderMenuCards();

  if (categoryId !== "all") {
    setTimeout(() => {
      const targetSection = document.getElementById(`section-${categoryId}`);
      if (targetSection) {
        targetSection.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }, 60);
  }
}

// Dietary Filtering
function initDietaryFilters() {
  const buttons = document.querySelectorAll(".diet-filter-btn");
  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      buttons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      activeDietFilter = btn.dataset.diet;
      renderMenuCards();
    });
  });
}

// Search Input Listener
function initSearch() {
  const searchInput = document.getElementById("menu-search-input");
  if (!searchInput) return;

  searchInput.addEventListener("input", (e) => {
    searchQuery = e.target.value.toLowerCase().trim();
    renderMenuCards();
  });
}

// Single Food Card Component
function renderSingleProductCard(item) {
  const qtyInCart = window.spiceCart ? window.spiceCart.getItemQuantity(item.id) : 0;
  const isOutOfStock = item.available === false;

  return `
    <div class="product-card fade-in" id="card-${item.id}">
      <div class="card-media">
        <img src="${item.image}" alt="${item.name} - Spice Street" class="card-img" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=700&auto=format&fit=crop&q=80'" />
        <div class="card-badges-top">
          <span class="badge-tag">${item.badge}</span>
          <div class="diet-indicator ${item.isVeg ? 'veg' : 'non-veg'}" title="${item.isVeg ? 'Pure Veg' : 'Non-Veg'}">
            <span class="dot"></span>
          </div>
        </div>
      </div>

      <div class="card-body">
        <div class="card-header-row">
          <h3 class="product-title">${item.name}</h3>
          <span class="product-rating">★ ${item.rating}</span>
        </div>

        <p class="product-description">${item.description}</p>

        <div class="card-footer-row">
          <div class="product-price">${formatCurrency(item.price)}</div>

          <div class="card-action-box">
            ${isOutOfStock ? `
              <span style="font-size: 0.8rem; color: var(--nonveg-red); font-weight: 700;">Sold Out</span>
            ` : qtyInCart > 0 ? `
              <div class="qty-stepper">
                <button class="stepper-btn" onclick="handleCardQtyChange('${item.id}', -1)">-</button>
                <span class="stepper-val">${qtyInCart}</span>
                <button class="stepper-btn" onclick="handleCardQtyChange('${item.id}', 1)">+</button>
              </div>
            ` : `
              <button class="add-to-cart-btn" onclick="handleCardAdd('${item.id}')">
                <span>+</span> ADD
              </button>
            `}
          </div>
        </div>
      </div>
    </div>
  `;
}

// Separated Menu Sections Renderer (Non-Veg Section, Pure Veg Section, Dessert Section, Beverages)
function renderMenuCards() {
  const container = document.getElementById("menu-sections-container") || document.getElementById("products-grid");
  if (!container) return;

  const sectionsToRender = MENU_SECTIONS.filter(sec => {
    return activeCategory === "all" || sec.id === activeCategory;
  });

  let totalItemsCount = 0;
  const sectionsHtml = sectionsToRender.map(sec => {
    const secItems = MENU_ITEMS.filter(item => {
      if (!sec.filter(item)) return false;
      const matchesDiet = (activeDietFilter === "all") ||
                          (activeDietFilter === "veg" && item.isVeg) ||
                          (activeDietFilter === "non-veg" && !item.isVeg);
      const matchesSearch = !searchQuery ||
                            item.name.toLowerCase().includes(searchQuery) ||
                            item.description.toLowerCase().includes(searchQuery);
      return matchesDiet && matchesSearch;
    });

    if (secItems.length === 0) return "";

    totalItemsCount += secItems.length;

    return `
      <section class="menu-section-block" id="section-${sec.id}">
        <div class="menu-section-header ${sec.badgeType}-header">
          <div>
            <div class="section-badge-pill ${sec.badgeType}">
              <span>${sec.icon}</span>
              <span>${sec.badgeText}</span>
            </div>
            <h3 class="menu-section-title">${sec.title}</h3>
            <p class="menu-section-desc">${sec.subtitle}</p>
          </div>
          <div class="section-count-tag">
            ${secItems.length} ${secItems.length === 1 ? 'Dish' : 'Dishes'}
          </div>
        </div>

        <div class="products-grid">
          ${secItems.map(item => renderSingleProductCard(item)).join("")}
        </div>
      </section>
    `;
  }).filter(Boolean).join("");

  if (totalItemsCount === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 4rem 1rem; width: 100%;">
        <div style="font-size: 3.5rem; margin-bottom: 0.75rem;">🍛</div>
        <h3 style="font-size: 1.35rem; margin-bottom: 0.5rem; font-family: 'Playfair Display', serif;">No dishes found in this section</h3>
        <p style="color: var(--text-muted); font-size: 0.9rem;">Try changing your search term or view all sections.</p>
        <button class="btn-primary" style="margin-top: 1.25rem; display: inline-flex;" onclick="resetFilters()">View All Sections</button>
      </div>
    `;
    return;
  }

  container.innerHTML = sectionsHtml;
}

window.renderMenuCards = renderMenuCards;

function resetFilters() {
  activeCategory = "all";
  activeDietFilter = "all";
  searchQuery = "";
  const searchInput = document.getElementById("menu-search-input");
  if (searchInput) searchInput.value = "";
  const dietButtons = document.querySelectorAll(".diet-filter-btn");
  dietButtons.forEach(b => {
    if (b.dataset.diet === "all") b.classList.add("active");
    else b.classList.remove("active");
  });
  renderCategoryPills();
  renderMenuCards();
}

function handleCardAdd(productId) {
  window.spiceCart.addItem(productId, 1);
  const product = MENU_ITEMS.find(i => i.id === productId);
  showToast(`Added ${product ? product.name : 'item'} to cart!`);
  renderMenuCards();
}

function handleCardQtyChange(productId, delta) {
  window.spiceCart.updateQuantity(productId, delta);
  renderMenuCards();
}

// Cart Synchronization & UI Drawing
function initCartSubscription() {
  window.spiceCart.subscribe(state => {
    updateHeaderCartBadges(state.totalCount);
    renderCartDrawerUI(state);
  });
}

function updateHeaderCartBadges(count) {
  const badges = document.querySelectorAll(".cart-count-badge");
  badges.forEach(b => {
    b.textContent = count;
    b.style.display = count > 0 ? "flex" : "none";
  });
}

function renderCartDrawerUI(state) {
  const itemsContainer = document.getElementById("cart-items-container");
  const emptyState = document.getElementById("cart-empty-state");
  const footerEl = document.getElementById("cart-footer");

  if (!itemsContainer || !emptyState || !footerEl) return;

  if (state.items.length === 0) {
    itemsContainer.style.display = "none";
    emptyState.style.display = "flex";
    footerEl.style.display = "none";
    return;
  }

  itemsContainer.style.display = "flex";
  emptyState.style.display = "none";
  footerEl.style.display = "block";

  itemsContainer.innerHTML = state.items.map(item => `
    <div class="cart-item-row">
      <img src="${item.image}" alt="${item.name}" class="cart-item-thumb" />
      <div class="cart-item-details">
        <div style="display: flex; align-items: center; gap: 0.35rem;">
          <div class="diet-indicator ${item.isVeg ? 'veg' : 'non-veg'}" style="transform: scale(0.85);">
            <span class="dot"></span>
          </div>
          <h4 class="cart-item-title">${item.name}</h4>
        </div>
        <div class="cart-item-price">${formatCurrency(item.price)} × ${item.quantity} = ${formatCurrency(item.price * item.quantity)}</div>
      </div>

      <div class="cart-item-actions">
        <div class="qty-stepper" style="border-width: 1px;">
          <button class="stepper-btn" style="width: 26px; height: 26px; font-size: 0.95rem;" onclick="window.spiceCart.updateQuantity('${item.id}', -1); renderMenuCards();">-</button>
          <span class="stepper-val" style="min-width: 22px; font-size: 0.8rem;">${item.quantity}</span>
          <button class="stepper-btn" style="width: 26px; height: 26px; font-size: 0.95rem;" onclick="window.spiceCart.updateQuantity('${item.id}', 1); renderMenuCards();">+</button>
        </div>
        <button class="cart-remove-btn" onclick="window.spiceCart.removeItem('${item.id}'); renderMenuCards();" title="Remove">✕</button>
      </div>
    </div>
  `).join("");

  // Update Bill Summary
  document.getElementById("cart-subtotal").textContent = formatCurrency(state.subtotal);
  document.getElementById("cart-delivery-fee").textContent = state.deliveryFee === 0 ? "FREE" : formatCurrency(state.deliveryFee);
  document.getElementById("cart-taxes").textContent = formatCurrency(state.taxes);
  document.getElementById("cart-grand-total").textContent = formatCurrency(state.grandTotal);
}

// Drawer & Modal Controls
function toggleCartDrawer(open) {
  const drawer = document.getElementById("cart-drawer");
  const backdrop = document.getElementById("modal-backdrop");
  if (!drawer || !backdrop) return;

  if (open) {
    backdrop.classList.add("open");
    drawer.classList.add("open");
  } else {
    drawer.classList.remove("open");
    if (!hasOtherOpenModals()) {
      backdrop.classList.remove("open");
    }
  }
}

function hasOtherOpenModals() {
  const centerModals = document.querySelectorAll(".center-modal.open");
  return centerModals.length > 0;
}

function closeAllModals() {
  const backdrop = document.getElementById("modal-backdrop");
  const drawer = document.getElementById("cart-drawer");
  const modals = document.querySelectorAll(".center-modal");

  if (backdrop) backdrop.classList.remove("open");
  if (drawer) drawer.classList.remove("open");
  modals.forEach(m => m.classList.remove("open"));
}

function openModal(modalId) {
  closeAllModals();
  const backdrop = document.getElementById("modal-backdrop");
  const modal = document.getElementById(modalId);
  if (backdrop && modal) {
    backdrop.classList.add("open");
    modal.classList.add("open");
  }
}

// Navigation Controls
function initNavigation() {
  const mobileMenuBtn = document.getElementById("mobile-menu-btn");
  const mobileNavPanel = document.getElementById("mobile-nav-panel");

  if (mobileMenuBtn && mobileNavPanel) {
    mobileMenuBtn.addEventListener("click", () => {
      mobileNavPanel.classList.toggle("open");
    });
  }

  // Close mobile nav when link is clicked
  const mobileLinks = document.querySelectorAll(".mobile-nav-link");
  mobileLinks.forEach(link => {
    link.addEventListener("click", () => {
      if (mobileNavPanel) mobileNavPanel.classList.remove("open");
    });
  });
}

// Checkout Flow
function proceedToCheckout() {
  const cartState = window.spiceCart.getState();
  if (cartState.items.length === 0) {
    showToast("Your cart is empty! Add dishes to proceed.");
    return;
  }

  // Populate checkout summary
  document.getElementById("checkout-subtotal").textContent = formatCurrency(cartState.subtotal);
  document.getElementById("checkout-delivery").textContent = cartState.deliveryFee === 0 ? "FREE" : formatCurrency(cartState.deliveryFee);
  document.getElementById("checkout-taxes").textContent = formatCurrency(cartState.taxes);
  document.getElementById("checkout-grand-total").textContent = formatCurrency(cartState.grandTotal);

  // Pre-populate saved customer data if exists
  const savedCustomerStr = localStorage.getItem("spice_street_customer");
  if (savedCustomerStr) {
    try {
      const c = JSON.parse(savedCustomerStr);
      if (c.fullName) document.getElementById("checkout-name").value = c.fullName;
      if (c.phone) document.getElementById("checkout-phone").value = c.phone;
      if (c.email) document.getElementById("checkout-email").value = c.email;
      if (c.flatNo) document.getElementById("checkout-flat").value = c.flatNo;
      if (c.street) document.getElementById("checkout-street").value = c.street;
      if (c.city) document.getElementById("checkout-city").value = c.city;
      if (c.pincode) document.getElementById("checkout-pincode").value = c.pincode;
      if (c.instructions) document.getElementById("checkout-instructions").value = c.instructions;
    } catch (e) {}
  }

  // Ensure current payment method is selected in modal
  selectPaymentMethod(window.checkoutController.selectedPaymentMethod || "gpay");

  toggleCartDrawer(false);
  openModal("checkout-modal");
}

function quickSelectCartPayment(method) {
  selectPaymentMethod(method);
}

function proceedWithOnlinePayment() {
  const method = window.checkoutController.selectedPaymentMethod;
  if (!method || method === "cod") {
    selectPaymentMethod("gpay");
  }
  proceedToCheckout();
}

function proceedWithCodPayment() {
  selectPaymentMethod("cod");
  proceedToCheckout();
}

function handleCheckoutSubmit(event) {
  if (event) event.preventDefault();

  const fullName = document.getElementById("checkout-name").value;
  const phone = document.getElementById("checkout-phone").value;
  const email = document.getElementById("checkout-email").value;
  const flatNo = document.getElementById("checkout-flat").value;
  const street = document.getElementById("checkout-street").value;
  const city = document.getElementById("checkout-city").value;
  const pincode = document.getElementById("checkout-pincode").value;
  const instructions = document.getElementById("checkout-instructions").value;

  const formData = { fullName, phone, email, flatNo, street, city, pincode, instructions };
  const validation = window.checkoutController.validateForm(formData);

  if (!validation.isValid) {
    showToast(validation.errors[0]);
    return;
  }

  // Save current customer info for fast future orders
  localStorage.setItem("spice_street_customer", JSON.stringify(formData));
  window.pendingCustomerData = formData;

  // Immediately confirm order based on selected payment method!
  closeAllModals();
  handlePaymentConfirm();
}

function updatePaymentModalTotal() {
  const cartState = window.spiceCart.getState();
  const totalDisplay = document.getElementById("payment-total-display");
  if (totalDisplay) {
    totalDisplay.textContent = formatCurrency(cartState.grandTotal);
  }
}

function selectPaymentMethod(method) {
  window.checkoutController.selectedPaymentMethod = method;
  
  // Highlight payment option cards in checkout modal
  document.querySelectorAll(".payment-option-card").forEach(c => c.classList.remove("selected"));
  const chosenCard = document.getElementById(`payment-card-${method}`);
  if (chosenCard) {
    chosenCard.classList.add("selected");
    const radio = chosenCard.querySelector("input[type='radio']");
    if (radio) radio.checked = true;
  }

  const chosenCardAlt = document.getElementById(`payment-card-${method}-alt`);
  if (chosenCardAlt) {
    chosenCardAlt.classList.add("selected");
    const radioAlt = chosenCardAlt.querySelector("input[type='radio']");
    if (radioAlt) radioAlt.checked = true;
  }

  // Highlight active pill in cart drawer
  document.querySelectorAll(".cart-pay-pill").forEach(p => p.classList.remove("active"));
  const chosenPill = document.getElementById(`cart-pill-${method}`);
  if (chosenPill) {
    chosenPill.classList.add("active");
  }

  // Update checkout modal submit button text
  const submitBtn = document.getElementById("checkout-submit-btn");
  if (submitBtn) {
    if (method === "cod") {
      submitBtn.innerHTML = `<span>💵 CONFIRM CASH ON DELIVERY ORDER</span>`;
    } else if (method === "card") {
      submitBtn.innerHTML = `<span>💳 PAY WITH CREDIT / DEBIT CARD</span>`;
    } else {
      const names = { gpay: "GOOGLE PAY", phonepe: "PHONEPE", paytm: "PAYTM", upi: "UPI QR" };
      submitBtn.innerHTML = `<span>⚡ PAY VIA ${names[method] || "ONLINE UPI"} (8341643180@ptyes)</span>`;
    }
  }
}

function handlePaymentConfirm() {
  const method = window.checkoutController.selectedPaymentMethod || "gpay";
  const customerData = window.pendingCustomerData;
  const cartState = window.spiceCart.getState();

  if (!customerData) {
    showToast("Please enter delivery details first.");
    openModal("checkout-modal");
    return;
  }

  if (method === "cod") {
    // Cash On Delivery Flow
    const order = window.checkoutController.createOrderObject(customerData, "Cash on Delivery (COD)", "COD / Pending");
    window.checkoutController.saveOrder(order);
    window.spiceCart.clearCart();
    renderMenuCards();
    
    // Automatically trigger WhatsApp with complete order details!
    sendWhatsAppOrderSummary(order.orderId);
    showOrderConfirmation(order);
    showToast("🎉 Order placed with COD! Opening WhatsApp automatically...");
  } else if (method === "card") {
    // Full Working Interactive Credit / Debit Card Flow
    showCardPaymentModal(cartState.grandTotal, customerData);
  } else {
    // UPI Flow (gpay, phonepe, paytm, or upi)
    const tempOrderId = window.checkoutController.generateOrderId();
    const upiUrl = window.checkoutController.buildUpiUrl(cartState.grandTotal, tempOrderId);

    // If mobile and clicked specific app, optionally trigger deep link
    if (window.innerWidth < 768) {
      if (method === "gpay") {
        window.location.href = `tez://upi/pay?pa=${RESTAURANT_INFO.upiVpa}&pn=${encodeURIComponent(RESTAURANT_INFO.merchantName)}&am=${cartState.grandTotal.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Order ' + tempOrderId)}`;
      } else if (method === "phonepe") {
        window.location.href = `phonepe://pay?pa=${RESTAURANT_INFO.upiVpa}&pn=${encodeURIComponent(RESTAURANT_INFO.merchantName)}&am=${cartState.grandTotal.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Order ' + tempOrderId)}`;
      } else if (method === "paytm") {
        window.location.href = `paytmmp://pay?pa=${RESTAURANT_INFO.upiVpa}&pn=${encodeURIComponent(RESTAURANT_INFO.merchantName)}&am=${cartState.grandTotal.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Order ' + tempOrderId)}`;
      } else {
        window.location.href = upiUrl;
      }
    }

    // Show UPI Verification Modal with QR code and active app highlight
    showUpiVerificationModal(tempOrderId, upiUrl, cartState.grandTotal, customerData, method);
  }
}

// 1-Click Direct WhatsApp Order from Cart Drawer
function directOrderOnWhatsAppFromCart() {
  const cartState = window.spiceCart.getState();
  if (cartState.items.length === 0) {
    showToast("Your cart is empty! Add dishes first.");
    return;
  }

  // Check if we have saved customer data in localStorage
  const savedCustomerStr = localStorage.getItem("spice_street_customer");
  if (savedCustomerStr) {
    try {
      const customerData = JSON.parse(savedCustomerStr);
      window.pendingCustomerData = customerData;
      const order = window.checkoutController.createOrderObject(customerData, "WhatsApp / Direct", "Pending Acceptance");
      window.checkoutController.saveOrder(order);
      window.spiceCart.clearCart();
      renderMenuCards();
      toggleCartDrawer(false);

      sendWhatsAppOrderSummary(order.orderId);
      showOrderConfirmation(order);
      showToast("🚀 Opening WhatsApp with your order details...");
      return;
    } catch(e) {
      // Fall through to open checkout modal
    }
  }

  // If no saved data, open checkout modal
  toggleCartDrawer(false);
  openModal("checkout-modal");
  showToast("Please enter delivery address to send order to WhatsApp!");
}

// Direct WhatsApp Order Submission from Checkout Form
function submitOrderToWhatsAppDirectly(event) {
  if (event) event.preventDefault();

  const fullName = document.getElementById("checkout-name").value;
  const phone = document.getElementById("checkout-phone").value;
  const email = document.getElementById("checkout-email").value;
  const flatNo = document.getElementById("checkout-flat").value;
  const street = document.getElementById("checkout-street").value;
  const city = document.getElementById("checkout-city").value;
  const pincode = document.getElementById("checkout-pincode").value;
  const instructions = document.getElementById("checkout-instructions").value;

  const formData = { fullName, phone, email, flatNo, street, city, pincode, instructions };
  const validation = window.checkoutController.validateForm(formData);

  if (!validation.isValid) {
    showToast(validation.errors[0]);
    return;
  }

  // Persist customer profile for future 1-click orders
  localStorage.setItem("spice_street_customer", JSON.stringify(formData));
  window.pendingCustomerData = formData;

  const order = window.checkoutController.createOrderObject(formData, "WhatsApp / Direct", "Pending Acceptance");
  window.checkoutController.saveOrder(order);
  window.spiceCart.clearCart();
  renderMenuCards();

  closeAllModals();

  // Automatically launch WhatsApp with formatted order message!
  sendWhatsAppOrderSummary(order.orderId);
  showOrderConfirmation(order);
  showToast("🎉 Order placed! Opening WhatsApp automatically...");
}

// UPI QR / Intent Flow Modal with GPay, PhonePe, Paytm, and Scanner
function showUpiVerificationModal(orderId, upiUrl, amount, customerData, preferredApp = "upi") {
  const vpa = RESTAURANT_INFO.upiVpa; // 8341643180@ptyes
  const qrImgUrl = window.checkoutController.getQrCodeUrl(upiUrl);

  const gpayUrl = `tez://upi/pay?pa=${vpa}&pn=${encodeURIComponent(RESTAURANT_INFO.merchantName)}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Order ' + orderId)}`;
  const phonepeUrl = `phonepe://pay?pa=${vpa}&pn=${encodeURIComponent(RESTAURANT_INFO.merchantName)}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Order ' + orderId)}`;
  const paytmUrl = `paytmmp://pay?pa=${vpa}&pn=${encodeURIComponent(RESTAURANT_INFO.merchantName)}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Order ' + orderId)}`;

  const appMeta = {
    gpay: { title: "Google Pay (G Pay)", icon: "🔵", label: "Open G Pay App", color: "#4285F4" },
    phonepe: { title: "PhonePe", icon: "🟣", label: "Open PhonePe App", color: "#5f259f" },
    paytm: { title: "Paytm UPI & Wallet", icon: "🔷", label: "Open Paytm App", color: "#00BAF2" },
    upi: { title: "Instant UPI & QR Scanner", icon: "⚡", label: "Open Any UPI App", color: "var(--gold-accent)" }
  };

  const currentApp = appMeta[preferredApp] || appMeta.upi;
  const container = document.getElementById("payment-gateway-modal-body");
  if (!container) return;

  container.innerHTML = `
    <div style="text-align: center;">
      <div style="display: inline-flex; align-items: center; gap: 0.4rem; background: rgba(255, 183, 3, 0.15); border: 1px solid var(--gold-accent); color: var(--gold-accent); padding: 0.3rem 0.85rem; border-radius: 99px; font-size: 0.78rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 0.5rem;">
        ${currentApp.icon} ${currentApp.title}
      </div>
      <h3 style="font-size: 1.35rem; margin-bottom: 0.2rem; font-family: 'Playfair Display', serif;">Pay ${formatCurrency(amount)}</h3>
      <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.85rem;">Scan using Google Pay, PhonePe, Paytm or any UPI App</p>

      <!-- QR Code Scanner Box -->
      <div style="display: inline-block; padding: 14px; background: #ffffff; border-radius: 16px; border: 3px solid var(--gold-accent); box-shadow: 0 8px 30px rgba(0,0,0,0.6); margin: 0.4rem 0;">
        <img src="${qrImgUrl}" alt="Spice Street UPI QR Scanner" style="width: 210px; height: 210px; display: block; border-radius: 8px;" />
        <div style="font-size: 0.75rem; color: #111; font-weight: 800; margin-top: 0.45rem; letter-spacing: 0.02em;">SCAN TO PAY • SPICE STREET</div>
      </div>

      <!-- UPI ID Copy Bar -->
      <div style="background: var(--bg-card); border: 1px dashed var(--border-accent); border-radius: var(--radius-md); padding: 0.75rem 1rem; margin: 0.85rem 0; display: flex; justify-content: space-between; align-items: center; gap: 0.5rem;">
        <div style="text-align: left;">
          <div style="font-size: 0.72rem; color: var(--text-muted); font-weight: 600;">Official UPI ID:</div>
          <div style="font-size: 1rem; font-weight: 800; color: var(--gold-accent); letter-spacing: 0.03em;" id="upi-id-val">${vpa}</div>
        </div>
        <button type="button" class="btn-outline" style="padding: 0.35rem 0.75rem; font-size: 0.78rem;" onclick="copyUpiIdToClipboard('${vpa}')">
          📋 Copy UPI ID
        </button>
      </div>

      <!-- Quick 1-Click Pay Buttons -->
      <div style="margin: 0.85rem 0;">
        <div style="font-size: 0.8rem; font-weight: 700; color: var(--text-secondary); margin-bottom: 0.45rem;">
          Tap to pay directly in your app:
        </div>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; margin-bottom: 0.5rem;">
          <a href="${gpayUrl}" class="btn-contact" style="justify-content: center; font-size: 0.82rem; font-weight: 700; border-color: #4285F4; color: #fff; background: ${preferredApp === 'gpay' ? 'rgba(66, 133, 244, 0.45); border-width: 2px;' : 'rgba(66, 133, 244, 0.15);'}">
            🔵 G Pay
          </a>
          <a href="${phonepeUrl}" class="btn-contact" style="justify-content: center; font-size: 0.82rem; font-weight: 700; border-color: #5f259f; color: #fff; background: ${preferredApp === 'phonepe' ? 'rgba(95, 37, 159, 0.45); border-width: 2px;' : 'rgba(95, 37, 159, 0.2);'}">
            🟣 PhonePe
          </a>
          <a href="${paytmUrl}" class="btn-contact" style="justify-content: center; font-size: 0.82rem; font-weight: 700; border-color: #00BAF2; color: #fff; background: ${preferredApp === 'paytm' ? 'rgba(0, 186, 242, 0.45); border-width: 2px;' : 'rgba(0, 186, 242, 0.15);'}">
            🔷 Paytm
          </a>
        </div>
        <a href="${upiUrl}" class="btn-primary" style="width: 100%; justify-content: center; font-size: 0.88rem; padding: 0.6rem;">
          ⚡ Open Any Other UPI App (BHIM / Cred / Bank)
        </a>
      </div>

      <!-- UTR Verification Box -->
      <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 0.85rem 1rem; text-align: left; margin-top: 0.85rem;">
        <div style="font-size: 0.82rem; font-weight: 700; color: var(--gold-accent); margin-bottom: 0.35rem;">
          After completing payment:
        </div>
        <div class="form-group" style="margin-bottom: 0.75rem;">
          <label class="form-label">12-Digit UPI Reference / UTR Number (Optional)</label>
          <input type="text" id="upi-utr-input" class="form-input" placeholder="e.g. 423589123456" maxlength="16" />
        </div>
        <button class="btn-primary checkout-btn" style="width: 100%; justify-content: center; font-size: 1.05rem; font-weight: 800; padding: 0.9rem;" onclick="verifyUpiAndFinalizeOrder('${orderId}', '${currentApp.title}')">
          🎉 CONFIRM PAYMENT & PLACE ORDER
        </button>
      </div>

      <button type="button" class="btn-outline" style="width: 100%; justify-content: center; margin-top: 0.65rem; font-size: 0.85rem; padding: 0.45rem;" onclick="openModal('checkout-modal')">
        ← Change Payment Method
      </button>
    </div>
  `;

  openModal("payment-gateway-modal");
}

function copyUpiIdToClipboard(upiId) {
  navigator.clipboard.writeText(upiId).then(() => {
    showToast(`✓ UPI ID copied: ${upiId}`);
  }).catch(() => {
    showToast(`UPI ID: ${upiId}`);
  });
}

function verifyUpiAndFinalizeOrder(orderId, appTitle = "UPI") {
  const customerData = window.pendingCustomerData;
  const utrInput = document.getElementById("upi-utr-input");
  const utr = utrInput ? utrInput.value.trim() : "";

  // Create verified order
  const order = window.checkoutController.createOrderObject(customerData, `UPI (${appTitle})`, "Paid");
  order.orderId = orderId;
  order.payment.transactionId = utr || `UPI_TXN_${Date.now()}`;

  window.checkoutController.saveOrder(order);
  window.spiceCart.clearCart();
  renderMenuCards();

  closeAllModals();

  showOrderConfirmation(order);
  showToast(`🎉 Payment confirmed! Directly opening WhatsApp...`);

  // Directly navigate to WhatsApp page!
  sendWhatsAppOrderSummary(order.orderId, true);
}

// Full Working Interactive Credit / Debit Card Modal
function showCardPaymentModal(amount, customerData) {
  const container = document.getElementById("payment-gateway-modal-body");
  if (!container) return;

  const defaultName = (customerData && customerData.fullName) ? customerData.fullName : "CARDHOLDER NAME";

  container.innerHTML = `
    <div>
      <div style="text-align: center; margin-bottom: 0.75rem;">
        <div style="display: inline-flex; align-items: center; gap: 0.4rem; background: rgba(34, 197, 94, 0.15); border: 1px solid var(--veg-green); color: #86efac; padding: 0.25rem 0.8rem; border-radius: 99px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase;">
          🔒 256-Bit Bank Grade Secure Checkout
        </div>
        <h3 style="font-size: 1.35rem; margin-top: 0.4rem; font-family: 'Playfair Display', serif;">Credit / Debit Card</h3>
        <p style="font-size: 0.82rem; color: var(--text-muted);">Visa • Mastercard • RuPay • Maestro</p>
      </div>

      <!-- Interactive Virtual Card Preview -->
      <div class="virtual-card-wrapper">
        <div class="virtual-card" id="virtual-card-element">
          <div class="virtual-card-top">
            <div class="virtual-card-chip"></div>
            <div class="virtual-card-brand-badge" id="card-preview-brand">VISA</div>
          </div>
          <div class="virtual-card-number" id="card-preview-number">•••• •••• •••• ••••</div>
          <div class="virtual-card-bottom">
            <div>
              <div class="virtual-card-lbl">Cardholder Name</div>
              <div class="virtual-card-name" id="card-preview-name">${defaultName.toUpperCase()}</div>
            </div>
            <div style="text-align: right;">
              <div class="virtual-card-lbl">Expires</div>
              <div class="virtual-card-expiry" id="card-preview-expiry">MM/YY</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Card Form Input Fields -->
      <form id="card-payment-form" onsubmit="handleCardFormSubmit(event, ${amount})">
        <div class="form-group" style="margin-bottom: 0.75rem;">
          <label class="form-label">Cardholder Name *</label>
          <input type="text" id="card-input-name" class="form-input" value="${defaultName}" required oninput="updateCardPreview()" />
        </div>

        <div class="form-group" style="margin-bottom: 0.75rem;">
          <label class="form-label">Card Number *</label>
          <div style="position: relative;">
            <input type="text" id="card-input-number" class="form-input" placeholder="4532 8912 3456 7890" maxlength="19" required oninput="formatCardNumberInput(this); updateCardPreview();" />
            <span id="card-type-icon" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-size: 1.1rem;">💳</span>
          </div>
        </div>

        <div class="card-input-grid">
          <div class="form-group">
            <label class="form-label">Expiry (MM / YY) *</label>
            <input type="text" id="card-input-expiry" class="form-input" placeholder="12/28" maxlength="5" required oninput="formatCardExpiry(this); updateCardPreview();" />
          </div>
          <div class="form-group">
            <label class="form-label">CVV / CVC *</label>
            <input type="password" id="card-input-cvv" class="form-input" placeholder="•••" maxlength="4" required />
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-md); border: 1px solid var(--border-subtle); margin: 0.85rem 0;">
          <span style="font-size: 0.85rem; color: var(--text-muted);">Amount to Deduct:</span>
          <span style="font-size: 1.2rem; font-weight: 800; color: var(--gold-accent);">${formatCurrency(amount)}</span>
        </div>

        <button type="submit" class="btn-primary checkout-btn" style="width: 100%; justify-content: center; font-size: 1.05rem; font-weight: 800; padding: 0.95rem;">
          🔒 Pay ${formatCurrency(amount)} Securely
        </button>

        <button type="button" class="btn-outline" style="width: 100%; justify-content: center; margin-top: 0.5rem; font-size: 0.85rem; padding: 0.45rem;" onclick="openModal('checkout-modal')">
          ← Choose Different Payment Method
        </button>
      </form>
    </div>
  `;

  openModal("payment-gateway-modal");
}

function formatCardNumberInput(input) {
  let val = input.value.replace(/\D/g, "").substring(0, 16);
  let formatted = val.match(/.{1,4}/g)?.join(" ") || val;
  input.value = formatted;
}

function formatCardExpiry(input) {
  let val = input.value.replace(/\D/g, "").substring(0, 4);
  if (val.length >= 2) {
    input.value = val.substring(0, 2) + "/" + val.substring(2);
  } else {
    input.value = val;
  }
}

function updateCardPreview() {
  const numInput = document.getElementById("card-input-number");
  const nameInput = document.getElementById("card-input-name");
  const expInput = document.getElementById("card-input-expiry");

  const numPreview = document.getElementById("card-preview-number");
  const namePreview = document.getElementById("card-preview-name");
  const expPreview = document.getElementById("card-preview-expiry");
  const brandPreview = document.getElementById("card-preview-brand");
  const cardIcon = document.getElementById("card-type-icon");

  if (numInput && numPreview) {
    const raw = numInput.value.replace(/\s+/g, "");
    numPreview.textContent = numInput.value || "•••• •••• •••• ••••";

    // Detect card brand
    if (raw.startsWith("4")) {
      if (brandPreview) brandPreview.textContent = "VISA";
      if (cardIcon) cardIcon.textContent = "🔷";
    } else if (raw.startsWith("5")) {
      if (brandPreview) brandPreview.textContent = "MASTERCARD";
      if (cardIcon) cardIcon.textContent = "🔴";
    } else if (raw.startsWith("6") || raw.startsWith("8")) {
      if (brandPreview) brandPreview.textContent = "RUPAY";
      if (cardIcon) cardIcon.textContent = "🟢";
    } else {
      if (brandPreview) brandPreview.textContent = "CARD";
      if (cardIcon) cardIcon.textContent = "💳";
    }
  }

  if (nameInput && namePreview) {
    namePreview.textContent = (nameInput.value || "CARDHOLDER NAME").toUpperCase();
  }

  if (expInput && expPreview) {
    expPreview.textContent = expInput.value || "MM/YY";
  }
}

function handleCardFormSubmit(event, amount) {
  if (event) event.preventDefault();

  const numInput = document.getElementById("card-input-number");
  const nameInput = document.getElementById("card-input-name");
  const expInput = document.getElementById("card-input-expiry");
  const cvvInput = document.getElementById("card-input-cvv");

  const cardNum = numInput ? numInput.value.replace(/\s+/g, "") : "";
  if (cardNum.length < 15) {
    showToast("Please enter a valid 16-digit card number.");
    return;
  }

  const expiry = expInput ? expInput.value.trim() : "";
  if (expiry.length < 5 || !expiry.includes("/")) {
    showToast("Please enter a valid expiry date (MM/YY).");
    return;
  }

  const cvv = cvvInput ? cvvInput.value.trim() : "";
  if (cvv.length < 3) {
    showToast("Please enter a valid 3 or 4 digit CVV.");
    return;
  }

  const last4 = cardNum.slice(-4);
  const cardData = {
    holderName: nameInput ? nameInput.value.trim() : "",
    last4: last4,
    brand: cardNum.startsWith("4") ? "Visa" : cardNum.startsWith("5") ? "Mastercard" : "RuPay"
  };

  showCardOtpVerification(cardData, amount, window.pendingCustomerData);
}

// Realistic 3D-Secure Bank OTP Verification
function showCardOtpVerification(cardData, amount, customerData) {
  const container = document.getElementById("payment-gateway-modal-body");
  if (!container) return;

  const phone = customerData && customerData.phone ? customerData.phone : "8341643180";
  const maskedPhone = `+91 ******${phone.slice(-4)}`;

  container.innerHTML = `
    <div style="text-align: center;">
      <!-- Bank Verified Header -->
      <div style="background: rgba(66, 133, 244, 0.12); border: 1px solid rgba(66, 133, 244, 0.3); border-radius: var(--radius-md); padding: 0.85rem; margin-bottom: 1rem; display: flex; align-items: center; justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 0.5rem;">
          <span style="font-size: 1.3rem;">🏦</span>
          <div style="text-align: left;">
            <div style="font-size: 0.72rem; color: #93c5fd; font-weight: 700; text-transform: uppercase;">Bank 3D-Secure 2.0</div>
            <div style="font-size: 0.92rem; font-weight: 800; color: #fff;">Verified by ${cardData.brand}</div>
          </div>
        </div>
        <span style="background: rgba(34,197,94,0.2); color: #86efac; font-size: 0.7rem; font-weight: 800; padding: 0.2rem 0.5rem; border-radius: 4px;">SECURE</span>
      </div>

      <h3 style="font-size: 1.25rem; margin-bottom: 0.25rem; font-family: 'Playfair Display', serif;">One-Time Password (OTP)</h3>
      <p style="font-size: 0.82rem; color: var(--text-secondary); margin-bottom: 1rem;">
        An authentication OTP has been dispatched to your mobile number <strong>${maskedPhone}</strong>.
      </p>

      <!-- Transaction Details Brief -->
      <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 0.85rem 1rem; text-align: left; font-size: 0.82rem; margin-bottom: 1.25rem;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 0.35rem;">
          <span style="color: var(--text-muted);">Merchant:</span>
          <strong>Spice Street Restaurant</strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 0.35rem;">
          <span style="color: var(--text-muted);">Card:</span>
          <strong>${cardData.brand} •••• ${cardData.last4}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; font-weight: 800; border-top: 1px dashed var(--border-subtle); padding-top: 0.35rem; margin-top: 0.35rem;">
          <span>Transaction Amount:</span>
          <span style="color: var(--gold-accent); font-size: 1rem;">${formatCurrency(amount)}</span>
        </div>
      </div>

      <!-- OTP Entry Form -->
      <div class="form-group" style="text-align: center; margin-bottom: 1rem;">
        <label class="form-label" style="font-size: 0.85rem; font-weight: 700; color: var(--gold-accent); margin-bottom: 0.5rem; display: block;">
          Enter 6-Digit Banking OTP
        </label>
        <input type="text" id="bank-otp-input" class="form-input otp-input-field" placeholder="• • • • • •" maxlength="6" autofocus />
        
        <div style="margin-top: 0.6rem; display: flex; justify-content: center; gap: 0.5rem; align-items: center;">
          <span style="font-size: 0.78rem; color: var(--text-muted);">Demo OTP: <strong style="color: var(--gold-accent);">834164</strong></span>
          <button type="button" class="btn-outline" style="padding: 0.15rem 0.5rem; font-size: 0.72rem;" onclick="document.getElementById('bank-otp-input').value='834164'">
            ⚡ 1-Click Auto-Fill
          </button>
        </div>
      </div>

      <div id="otp-status-message" style="display: none; padding: 0.6rem; border-radius: var(--radius-sm); font-size: 0.85rem; margin-bottom: 0.85rem;"></div>

      <button type="button" class="btn-primary checkout-btn" id="btn-submit-otp" style="width: 100%; justify-content: center; font-size: 1.05rem; font-weight: 800; padding: 0.9rem;" onclick="verifyCardOtpAndFinalize('${cardData.brand}', '${cardData.last4}', ${amount})">
        ✅ Submit OTP & Authorize Payment
      </button>

      <div style="margin-top: 0.75rem; display: flex; justify-content: space-between; align-items: center; font-size: 0.78rem; color: var(--text-muted);">
        <span>Resend OTP in <strong>24s</strong></span>
        <a href="javascript:void(0)" onclick="showCardPaymentModal(${amount}, window.pendingCustomerData)" style="color: var(--gold-accent); text-decoration: underline;">
          ← Edit Card Details
        </a>
      </div>
    </div>
  `;
}

function verifyCardOtpAndFinalize(brand, last4, amount) {
  const otpInput = document.getElementById("bank-otp-input");
  const otp = otpInput ? otpInput.value.trim() : "";
  const statusMsg = document.getElementById("otp-status-message");
  const btn = document.getElementById("btn-submit-otp");

  if (!otp || otp.length < 4) {
    showToast("Please enter the 6-digit OTP sent to your phone.");
    return;
  }

  // Show authorization in progress
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Verifying with Bank Server...";
  }

  if (statusMsg) {
    statusMsg.style.display = "block";
    statusMsg.style.background = "rgba(66, 133, 244, 0.15)";
    statusMsg.style.color = "#93c5fd";
    statusMsg.textContent = "⏳ Contacting issuing bank 3D-Secure ACS...";
  }

  setTimeout(() => {
    const customerData = window.pendingCustomerData;
    const authCode = `AUTH_${brand.toUpperCase()}_${Math.floor(100000 + Math.random() * 900000)}`;

    const order = window.checkoutController.createOrderObject(
      customerData,
      `Card (${brand} •••• ${last4})`,
      "Paid"
    );
    order.payment.transactionId = authCode;

    window.checkoutController.saveOrder(order);
    window.spiceCart.clearCart();
    renderMenuCards();

    closeAllModals();

    showOrderConfirmation(order);
    showToast(`🎉 Card payment authorized! Directly opening WhatsApp...`);

    // Directly navigate to WhatsApp page!
    sendWhatsAppOrderSummary(order.orderId, true);
  }, 1200);
}

// Build WhatsApp Order URL helper
function getWhatsAppOrderUrl(order) {
  if (!order) return `https://api.whatsapp.com/send?phone=${RESTAURANT_INFO.whatsapp}`;

  const itemsText = order.items.map(i => `  • ${i.quantity}x ${i.name} (${formatCurrency(i.price * i.quantity)})`).join("%0A");
  const isPaid = order.payment && (order.payment.status.toLowerCase().includes("paid") || !order.payment.method.toLowerCase().includes("cod"));

  const msg = 
`*🍽️ SPICE STREET - ${isPaid ? 'PAID ORDER' : 'NEW ORDER'} %23${order.orderId}*%0A` +
`━━━━━━━━━━━━━━━━━━━━%0A` +
`*Date:* ${encodeURIComponent(order.displayDate)}%0A%0A` +
`*👤 CUSTOMER DETAILS:*%0A` +
`• *Name:* ${encodeURIComponent(order.customer.fullName)}%0A` +
`• *Phone:* ${encodeURIComponent(order.customer.phone)}%0A` +
`${order.customer.email ? `• *Email:* ${encodeURIComponent(order.customer.email)}%0A` : ''}` +
`%0A*📍 DELIVERY ADDRESS:*%0A` +
`${encodeURIComponent(order.customer.address.flatNo + ', ' + order.customer.address.street)}%0A` +
`${encodeURIComponent(order.customer.address.city + ', Telangana - ' + order.customer.address.pincode)}%0A` +
`${order.customer.deliveryInstructions ? `*Note:* ${encodeURIComponent(order.customer.deliveryInstructions)}%0A` : ''}` +
`%0A*🍛 ORDERED FOOD ITEMS:*%0A` +
`${itemsText}%0A` +
`━━━━━━━━━━━━━━━━━━━━%0A` +
`*Subtotal:* ${encodeURIComponent(formatCurrency(order.pricing.subtotal))}%0A` +
`*Delivery Charge:* ${encodeURIComponent(order.pricing.deliveryFee === 0 ? 'FREE' : formatCurrency(order.pricing.deliveryFee))}%0A` +
`*Taxes (5% GST):* ${encodeURIComponent(formatCurrency(order.pricing.taxes))}%0A` +
`*TOTAL PAYABLE:* ${encodeURIComponent(formatCurrency(order.pricing.grandTotal))}%0A` +
`━━━━━━━━━━━━━━━━━━━━%0A` +
`*Payment Mode:* ${encodeURIComponent(order.payment.method.toUpperCase())}%0A` +
`*Payment Status:* ${encodeURIComponent(order.payment.status)}%0A` +
`${order.payment.transactionId ? `*Transaction/UTR:* ${encodeURIComponent(order.payment.transactionId)}%0A` : ''}` +
`%0A${isPaid ? '✅ *ONLINE PAYMENT DONE & VERIFIED!*%0APlease accept order & start cooking.' : '💵 *CASH ON DELIVERY ORDER*%0APlease confirm acceptance and estimated delivery time!'}`;

  return `https://api.whatsapp.com/send?phone=${RESTAURANT_INFO.whatsapp}&text=${msg}`;
}

// Order Confirmation Modal
function showOrderConfirmation(order) {
  const content = document.getElementById("confirmation-modal-body");
  if (!content) return;

  const itemsList = order.items.map(i => `
    <div style="display: flex; justify-content: space-between; font-size: 0.88rem; padding: 0.35rem 0;">
      <span>${i.quantity}x ${i.name}</span>
      <span style="font-weight: 600; color: var(--primary-orange);">${formatCurrency(i.price * i.quantity)}</span>
    </div>
  `).join("");

  const waUrl = getWhatsAppOrderUrl(order);

  content.innerHTML = `
    <div class="order-success-banner">
      <div class="success-icon-bubble">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
      </div>
      <h2 style="font-family: 'Playfair Display', serif; font-size: 1.8rem; margin-bottom: 0.35rem;">🎉 Order Confirmed!</h2>
      <p style="color: var(--text-secondary); font-size: 0.95rem;">Thank you for ordering from Spice Street, <strong>${order.customer.fullName}</strong>!</p>
      
      <div class="order-id-badge">Order #${order.orderId}</div>
      <div style="font-size: 0.82rem; color: var(--gold-accent); margin-top: 0.25rem;">Estimated Delivery: <strong>${order.estimatedDeliveryTime}</strong></div>
    </div>

    <!-- Direct WhatsApp Redirect Notification -->
    <div style="background: rgba(34, 197, 94, 0.15); border: 1px solid rgba(34, 197, 94, 0.4); border-radius: var(--radius-md); padding: 0.85rem 1rem; margin-bottom: 1.1rem; text-align: center;">
      <div style="font-size: 0.92rem; font-weight: 800; color: #86efac; margin-bottom: 0.25rem; display: flex; align-items: center; justify-content: center; gap: 0.4rem;">
        <span>🚀</span> Directly opening WhatsApp with your order receipt...
      </div>
      <div style="font-size: 0.78rem; color: #cbd5e1;">
        If WhatsApp doesn't open automatically in 2 seconds, tap the green button below!
      </div>
    </div>

    <!-- Order Summary Box -->
    <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1.25rem;">
      <h4 style="font-size: 0.95rem; margin-bottom: 0.75rem; color: var(--gold-accent);">Order Details</h4>
      <div style="border-bottom: 1px dashed var(--border-subtle); padding-bottom: 0.5rem; margin-bottom: 0.5rem;">
        ${itemsList}
      </div>
      <div style="display: flex; justify-content: space-between; font-size: 0.85rem; color: var(--text-muted);">
        <span>Delivery Address</span>
        <span style="text-align: right; max-width: 60%; color: var(--text-secondary);">${order.customer.address.street}, ${order.customer.address.city}</span>
      </div>
      <div style="display: flex; justify-content: space-between; font-size: 0.85rem; color: var(--text-muted); margin-top: 0.25rem;">
        <span>Payment Method</span>
        <span style="color: var(--veg-green); font-weight: 700;">${order.payment.method.toUpperCase()} (${order.payment.status})</span>
      </div>
      <div style="display: flex; justify-content: space-between; font-size: 1.05rem; font-weight: 800; border-top: 1px solid var(--border-subtle); padding-top: 0.5rem; margin-top: 0.5rem;">
        <span>Total Paid</span>
        <span style="color: var(--gold-accent);">${formatCurrency(order.pricing.grandTotal)}</span>
      </div>
    </div>

    <!-- Action Buttons with Prominent Direct WhatsApp Button -->
    <div style="display: flex; flex-direction: column; gap: 0.75rem;">
      <a href="${waUrl}" class="btn-contact btn-whatsapp" style="justify-content: center; font-size: 1.05rem; font-weight: 800; padding: 1rem; text-decoration: none; background: #25D366; color: #fff; box-shadow: 0 4px 20px rgba(37, 211, 102, 0.45); border-radius: var(--radius-md); display: flex; align-items: center; gap: 0.5rem;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
        </svg>
        <span>💬 OPEN WHATSAPP NOW (SEND ORDER)</span>
      </a>
      <button class="btn-primary" style="justify-content: center;" onclick="viewOrderTracking('${order.orderId}')">
        🚀 Track Order Live
      </button>
      <button class="btn-outline" style="justify-content: center;" onclick="closeAllModals()">
        Back to Home
      </button>
    </div>
  `;

  openModal("confirmation-modal");
}

function viewOrderTracking(orderId) {
  openModal("tracking-modal");
  window.trackingController.renderTracking(orderId);
}

function showTrackSearchPrompt() {
  const orderId = prompt("Please enter your Order ID (e.g. SS-1234-5678):");
  if (orderId) {
    viewOrderTracking(orderId);
  }
}

// WhatsApp Direct Automatic Integration
function sendWhatsAppOrderSummary(orderId, redirectDirectly = true) {
  const order = window.trackingController.getOrder(orderId);
  if (!order) return;

  const waUrl = getWhatsAppOrderUrl(order);

  if (redirectDirectly) {
    // Automatically navigate directly to the WhatsApp page!
    setTimeout(() => {
      window.location.href = waUrl;
    }, 600);
  } else {
    // If called from user click, try popup then direct
    try {
      const waWindow = window.open(waUrl, "_blank");
      if (!waWindow || waWindow.closed || typeof waWindow.closed === "undefined") {
        window.location.href = waUrl;
      }
    } catch (e) {
      window.location.href = waUrl;
    }
  }
}

function openWhatsAppOrderUpdate(orderId) {
  const msg = encodeURIComponent(`Hi Spice Street! I would like an update on my order #${orderId}.`);
  window.open(`https://wa.me/${RESTAURANT_INFO.whatsapp}?text=${msg}`, "_blank");
}

// Toast System
function showToast(message) {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `
    <span style="color: var(--gold-accent);">✦</span>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(100%)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}
window.showToast = showToast;
