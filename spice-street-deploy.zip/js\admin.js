// Spice Street - Restaurant Owner & Admin Dashboard
// Protected by PIN authentication: 1234
// Allows order tracking status management, COD tracking, menu pricing & stock controls

const ADMIN_PIN = "1234";

class AdminManager {
  constructor() {
    this.isAuthenticated = false;
  }

  verifyPin(inputPin) {
    if (inputPin === ADMIN_PIN) {
      this.isAuthenticated = true;
      return true;
    }
    return false;
  }

  renderDashboard() {
    const container = document.getElementById("admin-content");
    if (!container) return;

    if (!this.isAuthenticated) {
      container.innerHTML = `
        <div style="max-width: 360px; margin: 2rem auto; text-align: center; background: var(--bg-card); padding: 2rem; border-radius: var(--radius-lg); border: 1px solid var(--border-accent);">
          <div style="font-size: 2.5rem; margin-bottom: 0.75rem;">🔒</div>
          <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.5rem;">Spice Street Admin Portal</h3>
          <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1.5rem;">Restricted to restaurant staff. Enter Admin Security PIN.</p>
          <div class="form-group">
            <input type="password" id="admin-pin-input" class="form-input" placeholder="Enter PIN (Default: 1234)" style="text-align: center; font-size: 1.2rem; letter-spacing: 0.3em;" maxlength="6" autofocus />
          </div>
          <button class="btn-primary" style="width: 100%; justify-content: center; margin-top: 0.5rem;" onclick="submitAdminPin()">
            Unlock Dashboard
          </button>
          <p id="admin-pin-error" style="color: var(--nonveg-red); font-size: 0.8rem; margin-top: 0.75rem; display: none;">Invalid PIN. Please try again.</p>
        </div>
      `;
      return;
    }

    const orders = window.checkoutController ? window.checkoutController.getAllOrders() : [];
    const menuItems = MENU_ITEMS;

    container.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
        <div>
          <h3 style="font-size: 1.3rem; font-weight: 800; color: var(--text-primary);">Restaurant Operations Dashboard</h3>
          <p style="font-size: 0.82rem; color: var(--text-muted);">Real-time live incoming orders & menu controls</p>
        </div>
        <div style="display: flex; gap: 0.5rem;">
          <button class="btn-outline" style="padding: 0.45rem 0.9rem; font-size: 0.82rem;" onclick="adminManager.renderOrdersTab()">📋 Orders (${orders.length})</button>
          <button class="btn-outline" style="padding: 0.45rem 0.9rem; font-size: 0.82rem;" onclick="adminManager.renderMenuTab()">🍲 Menu Items (${menuItems.length})</button>
          <button class="btn-contact" style="padding: 0.45rem 0.9rem; font-size: 0.82rem; border-color: var(--nonveg-red); color: var(--nonveg-red);" onclick="adminManager.logout()">Logout</button>
        </div>
      </div>

      <div id="admin-tab-content">
        <!-- Injected dynamically -->
      </div>
    `;

    this.renderOrdersTab();
  }

  logout() {
    this.isAuthenticated = false;
    this.renderDashboard();
  }

  renderOrdersTab() {
    const tabContent = document.getElementById("admin-tab-content");
    if (!tabContent) return;

    const orders = window.checkoutController ? window.checkoutController.getAllOrders() : [];

    if (orders.length === 0) {
      tabContent.innerHTML = `
        <div style="text-align: center; padding: 3rem; background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
          <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🍽️</div>
          <h4>No orders placed yet</h4>
          <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 0.25rem;">Orders submitted on the website will appear here in real time.</p>
        </div>
      `;
      return;
    }

    const rows = orders.map(order => {
      const isCod = order.payment.method.toLowerCase().includes("cod");
      const paymentBadge = isCod 
        ? `<span style="background: rgba(255,183,3,0.15); color: var(--gold-accent); padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.72rem; font-weight: 700;">COD (${order.payment.status})</span>`
        : `<span style="background: rgba(34,197,94,0.15); color: var(--veg-green); padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.72rem; font-weight: 700;">ONLINE (Paid)</span>`;

      const itemsList = order.items.map(i => `${i.quantity}x ${i.name}`).join(", ");

      return `
        <tr>
          <td>
            <strong>#${order.orderId}</strong><br/>
            <span style="font-size: 0.72rem; color: var(--text-muted);">${order.displayDate}</span>
          </td>
          <td>
            <strong>${order.customer.fullName}</strong><br/>
            <span style="font-size: 0.75rem; color: var(--text-secondary);">${order.customer.phone}</span><br/>
            <span style="font-size: 0.72rem; color: var(--text-dim);">${order.customer.address.street}, ${order.customer.address.city}</span>
          </td>
          <td style="max-width: 220px; font-size: 0.8rem;">
            ${itemsList}
          </td>
          <td>
            <strong style="color: var(--gold-accent);">${formatCurrency(order.pricing.grandTotal)}</strong><br/>
            ${paymentBadge}
          </td>
          <td>
            <select onchange="adminManager.changeOrderStatus('${order.orderId}', this.value)" style="background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--border-accent); padding: 0.35rem 0.6rem; border-radius: var(--radius-sm); font-size: 0.8rem; font-weight: 600;">
              <option value="Order Received" ${order.status === 'Order Received' ? 'selected' : ''}>Order Received</option>
              <option value="Order Confirmed" ${order.status === 'Order Confirmed' ? 'selected' : ''}>Order Confirmed</option>
              <option value="Preparing" ${order.status === 'Preparing' ? 'selected' : ''}>Preparing</option>
              <option value="Out for Delivery" ${order.status === 'Out for Delivery' ? 'selected' : ''}>Out for Delivery</option>
              <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
            </select>
          </td>
        </tr>
      `;
    }).join("");

    tabContent.innerHTML = `
      <div style="overflow-x: auto; background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border-subtle); padding: 0.5rem;">
        <table class="admin-table">
          <thead>
            <tr>
              <th>Order ID / Time</th>
              <th>Customer & Address</th>
              <th>Items</th>
              <th>Amount & Payment</th>
              <th>Update Status</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>
      </div>
    `;
  }

  changeOrderStatus(orderId, newStatus) {
    const orders = window.checkoutController.getAllOrders();
    const order = orders.find(o => o.orderId === orderId);
    if (order) {
      order.status = newStatus;
      if (newStatus === "Delivered" && order.payment.method.toLowerCase().includes("cod")) {
        order.payment.status = "Paid (COD Collected)";
      }
      window.checkoutController.saveOrder(order);
      showToast(`Order #${orderId} status updated to: ${newStatus}`);
      this.renderOrdersTab();
    }
  }

  renderMenuTab() {
    const tabContent = document.getElementById("admin-tab-content");
    if (!tabContent) return;

    const rows = MENU_ITEMS.map(item => {
      return `
        <tr>
          <td>
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <img src="${item.image}" style="width: 40px; height: 40px; border-radius: 6px; object-fit: cover;" />
              <div>
                <strong>${item.name}</strong><br/>
                <span style="font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase;">${item.category}</span>
              </div>
            </div>
          </td>
          <td>
            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <span>₹</span>
              <input type="number" value="${item.price}" style="width: 70px; padding: 0.3rem 0.5rem; background: var(--bg-surface); border: 1px solid var(--border-subtle); border-radius: 4px; color: var(--gold-accent); font-weight: 700;" onchange="adminManager.updateItemPrice('${item.id}', this.value)" />
            </div>
          </td>
          <td>
            <button class="btn-contact" style="padding: 0.35rem 0.75rem; font-size: 0.75rem; border-color: ${item.available !== false ? 'var(--veg-green)' : 'var(--nonveg-red)'}; color: ${item.available !== false ? 'var(--veg-green)' : 'var(--nonveg-red)'};" onclick="adminManager.toggleAvailability('${item.id}')">
              ${item.available !== false ? '● In Stock' : '○ Out of Stock'}
            </button>
          </td>
        </tr>
      `;
    }).join("");

    tabContent.innerHTML = `
      <div style="overflow-x: auto; background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border-subtle); padding: 0.5rem;">
        <table class="admin-table">
          <thead>
            <tr>
              <th>Dish & Category</th>
              <th>Price (₹)</th>
              <th>Stock Status</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>
      </div>
    `;
  }

  updateItemPrice(itemId, newPrice) {
    const item = MENU_ITEMS.find(i => i.id === itemId);
    if (item) {
      item.price = Math.max(10, parseInt(newPrice) || item.price);
      showToast(`Updated price for ${item.name} to ${formatCurrency(item.price)}`);
      // Re-render menu on user facing side
      if (window.renderMenuCards) window.renderMenuCards();
    }
  }

  toggleAvailability(itemId) {
    const item = MENU_ITEMS.find(i => i.id === itemId);
    if (item) {
      item.available = item.available === false ? true : false;
      showToast(`${item.name} is now ${item.available ? 'In Stock' : 'Out of Stock'}`);
      this.renderMenuTab();
      if (window.renderMenuCards) window.renderMenuCards();
    }
  }
}

const adminManager = new AdminManager();
window.adminManager = adminManager;

function submitAdminPin() {
  const pinInput = document.getElementById("admin-pin-input");
  const errorMsg = document.getElementById("admin-pin-error");
  if (!pinInput) return;

  if (adminManager.verifyPin(pinInput.value.trim())) {
    adminManager.renderDashboard();
  } else {
    if (errorMsg) errorMsg.style.display = "block";
    pinInput.value = "";
    pinInput.focus();
  }
}
