// Spice Street - Food Menu & Restaurant Catalog Data
// Currency: Indian Rupee (₹)

const RESTAURANT_INFO = {
  name: "Spice Street",
  tagline: "Good Food • Great Mood",
  headline: "Authentic Indian Flavours, Made Fresh",
  subtext: "Delicious biryanis, starters, curries, refreshing beverages and desserts — freshly prepared for you.",
  phone: "+91 8341643180",
  displayPhone: "+91 83416 43180",
  whatsapp: "918341643180",
  email: "orders@spicestreet.in",
  address: "Plot 42, Food Street, Near Metro Station, Madhapur, Hyderabad, Telangana - 500081",
  timing: "11:30 AM – 11:30 PM (All Days)",
  deliveryFee: 40,
  freeDeliveryThreshold: 500,
  gstRate: 0.05, // 5% GST for restaurant orders
  upiVpa: "8341643180@ptyes",
  merchantName: "Spice Street Restaurant"
};

const MENU_SECTIONS = [
  {
    id: "non-veg",
    name: "Non-Veg Section",
    title: "🍗 Non-Veg Specials & Main Course",
    subtitle: "Authentic dum biryanis, fiery starters, and slow-cooked mutton & chicken curries prepared fresh to order.",
    icon: "🍗",
    badgeText: "NON-VEG DELICACIES",
    badgeType: "nonveg",
    filter: (item) => !item.isVeg && item.category !== "desserts" && item.category !== "beverages"
  },
  {
    id: "veg",
    name: "Pure Veg Section",
    title: "🥬 Pure Vegetarian Delights",
    subtitle: "Cooked in dedicated vegetarian cookware with fresh artisanal paneer, farm vegetables & pure desi ghee.",
    icon: "🥬",
    badgeText: "100% PURE VEG",
    badgeType: "veg",
    filter: (item) => item.isVeg && item.category !== "desserts" && item.category !== "beverages"
  },
  {
    id: "desserts",
    name: "Dessert Section",
    title: "🍨 Desserts & Sweet Mithai",
    subtitle: "Warm khoya Gulab Jamuns soaked in rose-cardamom sugar syrup and gourmet artisanal ice creams.",
    icon: "🍨",
    badgeText: "SWEET SPECIALS",
    badgeType: "dessert",
    filter: (item) => item.category === "desserts"
  },
  {
    id: "beverages",
    name: "Beverages Section",
    title: "🥤 Chilled Beverages & Coolers",
    subtitle: "Thick creamy Mango Lassi, fresh lime sodas, cold brewed coffee, and assorted chilled drinks.",
    icon: "🥤",
    badgeText: "CHILLED REFRESHERS",
    badgeType: "beverage",
    filter: (item) => item.category === "beverages"
  }
];

const CATEGORIES = [
  { id: "all", name: "✨ All Dishes", icon: "utensils" },
  { id: "non-veg", name: "🍗 Non-Veg Section", icon: "drumstick" },
  { id: "veg", name: "🥬 Pure Veg Section", icon: "leaf" },
  { id: "desserts", name: "🍨 Dessert Section", icon: "ice-cream" },
  { id: "beverages", name: "🥤 Beverages", icon: "cup-soda" }
];

const MENU_ITEMS = [
  // --- CATEGORY 1: BIRYANI & RICE ---
  {
    id: "biryani-1",
    name: "Chicken Biryani",
    category: "biryani",
    price: 180,
    isVeg: false,
    rating: 4.9,
    reviewsCount: 382,
    badge: "Bestseller",
    spiceLevel: 3, // 1 to 3
    description: "Fragrant long-grain basmati rice slow-cooked in dum style with succulent chicken pieces, caramelized onions, saffron milk, and secret royal spices. Served with cooling raita & salan.",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "biryani-2",
    name: "Mutton Biryani",
    category: "biryani",
    price: 250,
    isVeg: false,
    rating: 4.9,
    reviewsCount: 290,
    badge: "Chef's Special",
    spiceLevel: 3,
    description: "Tender, melt-in-mouth mutton cuts marinated overnight in spiced curd and slow-braised with aged basmati rice on sealed handi dum. Truly celebratory feast.",
    image: "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "biryani-3",
    name: "Veg Biryani",
    category: "biryani",
    price: 140,
    isVeg: true,
    rating: 4.7,
    reviewsCount: 175,
    badge: "Popular Veg",
    spiceLevel: 2,
    description: "Garden-fresh carrots, french beans, green peas, and paneer cubes infused with whole shahi garam masala, fresh mint, coriander, and saffron rice layers.",
    image: "https://images.unsplash.com/photo-1642821373181-696a54913e9a?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "biryani-4",
    name: "Jeera Rice",
    category: "biryani",
    price: 100,
    isVeg: true,
    rating: 4.6,
    reviewsCount: 98,
    badge: "Classic",
    spiceLevel: 1,
    description: "Fluffy basmati rice tempered with aromatic roasted cumin seeds (jeera), pure desi ghee, and fragrant bay leaves. Pairs exquisitely with our curries.",
    image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=700&auto=format&fit=crop&q=80",
    available: true
  },

  // --- CATEGORY 2: STARTERS ---
  {
    id: "starter-1",
    name: "Chicken 65",
    category: "starters",
    price: 160,
    isVeg: false,
    rating: 4.8,
    reviewsCount: 410,
    badge: "Bestseller",
    spiceLevel: 3,
    description: "Crispy, fiery deep-fried boneless chicken bites tossed with South Indian curry leaves, crushed pepper, ginger, garlic, and sliced green chillies.",
    image: "https://images.unsplash.com/photo-1610057099431-d73a1c9d2f2f?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "starter-2",
    name: "Chicken Lollipop",
    category: "starters",
    price: 180,
    isVeg: false,
    rating: 4.9,
    reviewsCount: 320,
    badge: "Must Try",
    spiceLevel: 2,
    description: "Crisp-fried chicken winglets french-cut into lollipops, coated in Indo-Chinese spice batter, served piping hot with tangy Schezwan dip.",
    image: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "starter-3",
    name: "Paneer Tikka",
    category: "starters",
    price: 150,
    isVeg: true,
    rating: 4.8,
    reviewsCount: 260,
    badge: "Tandoori Special",
    spiceLevel: 2,
    description: "Plump cubes of fresh malai paneer and crisp bell peppers marinated in spiced mustard yogurt and char-grilled in a clay tandoor oven. Sprinkled with chaat masala.",
    image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "starter-4",
    name: "Veg Spring Rolls",
    category: "starters",
    price: 120,
    isVeg: true,
    rating: 4.6,
    reviewsCount: 140,
    badge: "Crispy Crunch",
    spiceLevel: 1,
    description: "Golden crispy pastry rolls bursting with wok-tossed shredded cabbage, carrots, bell peppers, and scallions in light soy dressing. Accompanied with sweet chilli sauce.",
    image: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=700&auto=format&fit=crop&q=80",
    available: true
  },

  // --- CATEGORY 3: CURRIES ---
  {
    id: "curry-1",
    name: "Chicken Curry",
    category: "curries",
    price: 160,
    isVeg: false,
    rating: 4.8,
    reviewsCount: 305,
    badge: "Homestyle",
    spiceLevel: 3,
    description: "Tender chicken simmered in an authentic, robust onion-tomato gravy laced with roasted coriander seeds, cinnamon, and fresh herbs. Rich and deeply comforting.",
    image: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "curry-2",
    name: "Mutton Curry",
    category: "curries",
    price: 220,
    isVeg: false,
    rating: 4.9,
    reviewsCount: 245,
    badge: "Royal Rich",
    spiceLevel: 3,
    description: "Slow-braised tender mutton in a velvety, dark spiced brown onion gravy enriched with whole spices, Kashmiri red chilli, and a touch of roasted garam masala.",
    image: "https://images.unsplash.com/photo-1545247181-516773cae754?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "curry-3",
    name: "Paneer Butter Masala",
    category: "curries",
    price: 160,
    isVeg: true,
    rating: 4.9,
    reviewsCount: 390,
    badge: "Bestseller",
    spiceLevel: 1,
    description: "Soft artisanal cottage cheese cubes swimming in a luscious, silky tomato-cashew satin gravy finished with creamy butter and crushed aromatic kasuri methi.",
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "curry-4",
    name: "Dal Tadka",
    category: "curries",
    price: 120,
    isVeg: true,
    rating: 4.7,
    reviewsCount: 215,
    badge: "Desi Ghee",
    spiceLevel: 2,
    description: "Slow-boiled yellow arhar lentils tempered to sizzling perfection with pure desi ghee, golden fried garlic, whole red chillies, hing, and fresh cilantro.",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=700&auto=format&fit=crop&q=80",
    available: true
  },

  // --- CATEGORY 4: BEVERAGES ---
  {
    id: "bev-1",
    name: "Fresh Lime Soda",
    category: "beverages",
    price: 60,
    isVeg: true,
    rating: 4.8,
    reviewsCount: 160,
    badge: "Refreshing",
    spiceLevel: 0,
    description: "Sparkling chilled club soda blended with freshly squeezed key limes, rock salt, mint leaves, and sweet syrup. The ultimate palate refresher.",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "bev-2",
    name: "Mango Lassi",
    category: "beverages",
    price: 80,
    isVeg: true,
    rating: 4.9,
    reviewsCount: 310,
    badge: "Signature Drink",
    spiceLevel: 0,
    description: "Thick, creamy yogurt churned with sweet Alphonso mango pulp, green cardamom essence, and topped with sliced roasted pistachios.",
    image: "https://images.unsplash.com/photo-1571006687897-15d97f25906d?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "bev-3",
    name: "Cold Coffee",
    category: "beverages",
    price: 90,
    isVeg: true,
    rating: 4.7,
    reviewsCount: 185,
    badge: "Chilled Brew",
    spiceLevel: 0,
    description: "Freshly brewed dark espresso blended smooth with rich chilled milk, dark cocoa, and creamy vanilla ice cream. Served with cocoa dusting.",
    image: "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=700&auto=format&fit=crop&q=80",
    available: true
  },
  {
    id: "bev-4",
    name: "Soft Drinks",
    category: "beverages",
    price: 40,
    isVeg: true,
    rating: 4.5,
    reviewsCount: 95,
    badge: "Chilled",
    spiceLevel: 0,
    description: "Assorted chilled canned aerated beverages (Thums Up, Coca-Cola, Sprite). Served chilled with lemon wedge and ice.",
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=700&auto=format&fit=crop&q=80",
    available: true
  },

  // --- CATEGORY 5: DESSERTS ---
  {
    id: "dessert-1",
    name: "Gulab Jamun",
    category: "desserts",
    price: 70,
    isVeg: true,
    rating: 4.9,
    reviewsCount: 412,
    badge: "Crowd Favorite",
    spiceLevel: 0,
    description: "Two soft, golden fried khoya dumplings soaked in warm rose and green cardamom-perfumed sugar syrup. Garnished with silver vark and slivered almonds.",
    image: "assets/gulab_jamun.jpg",
    available: true
  },
  {
    id: "dessert-2",
    name: "Ice Cream",
    category: "desserts",
    price: 80,
    isVeg: true,
    rating: 4.7,
    reviewsCount: 220,
    badge: "Sweet Treat",
    spiceLevel: 0,
    description: "Two generous scoops of gourmet artisanal ice cream (choice of Shahi Kulfi, Belgian Chocolate, or Madagascan Vanilla) topped with roasted nuts and chocolate drizzle.",
    image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=700&auto=format&fit=crop&q=80",
    available: true
  }
];

// Helper to format currency in Indian format (e.g. ₹180, ₹1,250)
function formatCurrency(amount) {
  const num = Math.round(amount || 0);
  return "₹" + num.toLocaleString("en-IN");
}
