// Spice Street - Checkout & Payment Controller
// Strict Security: No card details, CVVs, or UPI PINs collected or stored.
// Implements COD, Official UPI Intent & QR, and Secure Hosted Gateway flow.

const ORDERS_STORAGE_KEY = "spice_street_orders_v1";

class CheckoutController {
  constructor() {
    this.selectedPaymentMethod = "cod";
    this.currentOrder = null;
    this.initOrdersStorage();
  }

  initOrdersStorage() {
    if (!localStorage.getItem(ORDERS_STORAGE_KEY)) {
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify([]));
    }
  }

  getAllOrders() {
    try {
      return JSON.parse(localStorage.getItem(ORDERS_STORAGE_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  saveOrder(order) {
    const orders = this.getAllOrders();
    // Check if updating existing
    const existingIndex = orders.findIndex(o => o.orderId === order.orderId);
    if (existingIndex > -1) {
      orders[existingIndex] = order;
    } else {
      orders.unshift(order);
    }
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));

    // 1. Sync with local PowerShell server
    this.syncOrderWithBackend(order);

    // 2. Automatically sync to Supabase Cloud Database!
    this.syncOrderToSupabase(order);
  }

  async syncOrderWithBackend(order) {
    try {
      await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order)
      });
    } catch (e) {
      // Backend is optional/local fallback
    }
  }

  async syncOrderToSupabase(order) {
    try {
      const config = {
        url: localStorage.getItem("spice_supabase_url") || "https://ifodvvqzpuoyhfwjtclw.supabase.co",
        anonKey: localStorage.getItem("spice_supabase_key") || "sb_publishable_nyRqCbF7fvOJ7UMZ2jISSw_mX5XXkqo"
      };

      if (window.supabase) {
        const client = window.supabase.createClient(config.url, config.anonKey);
        await client.from("orders").insert([
          {
            order_id: order.orderId,
            customer_name: order.customer.fullName,
            phone: order.customer.phone,
            email: order.customer.email || "",
            street_address: `${order.customer.address.flatNo || ''} ${order.customer.address.street || ''}`,
            landmark: order.customer.deliveryInstructions || "",
            pincode: order.customer.address.pincode || "",
            items: JSON.stringify(order.items),
            subtotal: order.pricing.subtotal,
            delivery_fee: order.pricing.deliveryFee,
            grand_total: order.pricing.grandTotal,
            payment_mode: order.payment.method,
            payment_status: order.payment.status,
            order_status: order.status,
            utr: order.payment.transactionId || "N/A"
          }
        ]);
        console.log("☁️ Order synced to Supabase Cloud:", order.orderId);
      }
    } catch (e) {
      console.warn("Supabase auto-sync failed (using local fallback):", e);
    }
  }

  generateOrderId() {
    const timestamp = Date.now().toString().slice(-4);
    const random = Math.floor(1000 + Math.random() * 9000);
    return `SS-${timestamp}-${random}`;
  }

  validateForm(formData) {
    const errors = [];
    if (!formData.fullName || formData.fullName.trim().length < 3) {
      errors.push("Please enter your full name (minimum 3 characters).");
    }

    const phoneRegex = /^[6-9]\d{9}$/;
    const cleanPhone = (formData.phone || "").replace(/\D/g, "");
    if (!phoneRegex.test(cleanPhone)) {
      errors.push("Please enter a valid 10-digit Indian mobile number (e.g. 9876543210).");
    }

    if (!formData.flatNo || formData.flatNo.trim().length < 1) {
      errors.push("Please enter your Flat / House / Floor number.");
    }

    if (!formData.street || formData.street.trim().length < 4) {
      errors.push("Please enter your Street / Area / Landmark.");
    }

    if (!formData.city || formData.city.trim().length < 2) {
      errors.push("Please enter your City.");
    }

    const pinRegex = /^[1-9][0-9]{5}$/;
    if (!pinRegex.test((formData.pincode || "").trim())) {
      errors.push("Please enter a valid 6-digit Indian PIN code.");
    }

    return {
      isValid: errors.length === 0,
      errors,
      cleanPhone
    };
  }

  createOrderObject(customerData, paymentMethod, paymentStatus = "Pending") {
    const cartState = window.spiceCart.getState();
    const orderId = this.generateOrderId();
    const now = new Date();

    const order = {
      orderId,
      createdAt: now.toISOString(),
      displayDate: now.toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }),
      customer: {
        fullName: customerData.fullName.trim(),
        phone: customerData.phone.trim(),
        email: (customerData.email || "").trim(),
        address: {
          flatNo: customerData.flatNo.trim(),
          street: customerData.street.trim(),
          city: customerData.city.trim(),
          state: customerData.state ? customerData.state.trim() : "Telangana",
          pincode: customerData.pincode.trim()
        },
        deliveryInstructions: (customerData.instructions || "").trim()
      },
      items: cartState.items,
      pricing: {
        subtotal: cartState.subtotal,
        deliveryFee: cartState.deliveryFee,
        taxes: cartState.taxes,
        grandTotal: cartState.grandTotal
      },
      payment: {
        method: paymentMethod, // 'cod', 'upi_gpay', 'upi_phonepe', 'upi_paytm', 'upi_qr', 'card'
        status: paymentStatus, // 'Pending', 'Paid', 'COD / Confirmed'
        transactionId: paymentStatus === "Paid" ? `TXN_${Date.now()}` : null
      },
      status: "Order Confirmed", // 'Order Received' -> 'Order Confirmed' -> 'Preparing' -> 'Out for Delivery' -> 'Delivered'
      estimatedDeliveryTime: "25-35 mins",
      shipment: {
        partner: Math.random() > 0.5 ? "Zomato Fleet" : "Swiggy Fleet",
        riderName: Math.random() > 0.5 ? "Rahul Sharma (Zomato Fleet)" : "Suresh Varma (Swiggy Fleet)",
        riderPhone: Math.random() > 0.5 ? "9849012345" : "9849055667",
        vehicleNo: Math.random() > 0.5 ? "TS 09 UB 8921" : "TS 08 AB 1144",
        rating: "4.9★",
        status: "Assigned"
      },
      deliveryRider: {
        partner: Math.random() > 0.5 ? "Zomato Fleet" : "Swiggy Fleet",
        name: "Express Delivery Partner",
        phone: "+91 98490 12345",
        status: "Assigned"
      }
    };

    // Keep deliveryRider synchronized with shipment
    order.deliveryRider.name = order.shipment.riderName;
    order.deliveryRider.phone = order.shipment.riderPhone;
    order.deliveryRider.partner = order.shipment.partner;

    return order;
  }

  // Generate UPI Intent URI according to NPCI specifications
  buildUpiUrl(amount, orderId) {
    const vpa = RESTAURANT_INFO.upiVpa;
    const name = encodeURIComponent(RESTAURANT_INFO.merchantName);
    const note = encodeURIComponent(`Order ${orderId} - Spice Street`);
    return `upi://pay?pa=${vpa}&pn=${name}&am=${amount.toFixed(2)}&cu=INR&tn=${note}`;
  }

  // Generate QR Code URL via free reliable QR API
  getQrCodeUrl(upiUrl) {
    return `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiUrl)}`;
  }
}

window.checkoutController = new CheckoutController();
