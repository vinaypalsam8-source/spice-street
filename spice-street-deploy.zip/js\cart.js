// Spice Street - Shopping Cart Module
// Handles add/remove/update, persistence in localStorage, and UI synchronization

const CART_STORAGE_KEY = "spice_street_cart_v1";

class CartManager {
  constructor() {
    this.items = this.loadCart();
    this.listeners = [];
  }

  loadCart() {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.warn("Could not load cart from localStorage", e);
      return [];
    }
  }

  saveCart() {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(this.items));
    } catch (e) {
      console.warn("Could not save cart to localStorage", e);
    }
    this.notify();
  }

  subscribe(callback) {
    this.listeners.push(callback);
    callback(this.getState());
  }

  notify() {
    const state = this.getState();
    this.listeners.forEach(cb => cb(state));
  }

  addItem(productId, quantity = 1) {
    const product = MENU_ITEMS.find(item => item.id === productId);
    if (!product) return false;

    const existingIndex = this.items.findIndex(i => i.id === productId);
    if (existingIndex > -1) {
      this.items[existingIndex].quantity += quantity;
    } else {
      this.items.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        isVeg: product.isVeg,
        quantity: Math.max(1, quantity)
      });
    }

    this.saveCart();
    return true;
  }

  updateQuantity(productId, delta) {
    const item = this.items.find(i => i.id === productId);
    if (!item) return;

    item.quantity += delta;
    if (item.quantity <= 0) {
      this.removeItem(productId);
    } else {
      this.saveCart();
    }
  }

  setQuantity(productId, exactQuantity) {
    const item = this.items.find(i => i.id === productId);
    if (!item) return;

    if (exactQuantity <= 0) {
      this.removeItem(productId);
    } else {
      item.quantity = exactQuantity;
      this.saveCart();
    }
  }

  removeItem(productId) {
    this.items = this.items.filter(i => i.id !== productId);
    this.saveCart();
  }

  clearCart() {
    this.items = [];
    this.saveCart();
  }

  getItemQuantity(productId) {
    const item = this.items.find(i => i.id === productId);
    return item ? item.quantity : 0;
  }

  getTotalCount() {
    return this.items.reduce((total, item) => total + item.quantity, 0);
  }

  getSubtotal() {
    return this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }

  getDeliveryFee() {
    const subtotal = this.getSubtotal();
    if (subtotal === 0) return 0;
    if (subtotal >= RESTAURANT_INFO.freeDeliveryThreshold) return 0;
    return RESTAURANT_INFO.deliveryFee;
  }

  getTaxes() {
    // 5% GST on food
    const subtotal = this.getSubtotal();
    return Math.round(subtotal * RESTAURANT_INFO.gstRate);
  }

  getGrandTotal() {
    const subtotal = this.getSubtotal();
    if (subtotal === 0) return 0;
    return subtotal + this.getDeliveryFee() + this.getTaxes();
  }

  getState() {
    return {
      items: [...this.items],
      totalCount: this.getTotalCount(),
      subtotal: this.getSubtotal(),
      deliveryFee: this.getDeliveryFee(),
      taxes: this.getTaxes(),
      grandTotal: this.getGrandTotal()
    };
  }
}

// Global Cart Instance
const cart = new CartManager();
window.spiceCart = cart;
