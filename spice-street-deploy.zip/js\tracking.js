// Spice Street - Live Order Tracking Controller
// Manages real-time visual progress through the 5 order states

const ORDER_STEPS = [
  { id: "Order Received", label: "Order Received", desc: "We have received your order details.", time: "0 min" },
  { id: "Order Confirmed", label: "Order Confirmed", desc: "Kitchen accepted and verified payment/order.", time: "2 mins" },
  { id: "Preparing", label: "Preparing in Kitchen", desc: "Chef is slow-cooking fresh biryani & curries.", time: "15 mins" },
  { id: "Out for Delivery", label: "Out for Delivery", desc: "Delivery partner is on the way to your door.", time: "25 mins" },
  { id: "Delivered", label: "Delivered", desc: "Delivered fresh & hot. Enjoy your meal!", time: "35 mins" }
];

class TrackingController {
  constructor() {
    this.activeTrackingOrderId = null;
  }

  getOrder(orderId) {
    const orders = window.checkoutController ? window.checkoutController.getAllOrders() : [];
    return orders.find(o => o.orderId.toLowerCase() === orderId.trim().toLowerCase());
  }

  renderTracking(orderId) {
    const order = this.getOrder(orderId);
    const trackingContainer = document.getElementById("tracking-content");
    if (!trackingContainer) return;

    if (!order) {
      trackingContainer.innerHTML = `
        <div style="text-align: center; padding: 2.5rem 1rem;">
          <div style="font-size: 3rem; margin-bottom: 1rem;">🔍</div>
          <h3 style="font-size: 1.3rem; margin-bottom: 0.5rem;">Order Not Found</h3>
          <p style="color: var(--text-muted); margin-bottom: 1.5rem;">We couldn't find an order matching "<strong>${orderId}</strong>". Please check the order ID.</p>
          <button class="btn-primary" onclick="showTrackSearchPrompt()">Enter Different Order ID</button>
        </div>
      `;
      return;
    }

    this.activeTrackingOrderId = order.orderId;
    const currentStepIndex = ORDER_STEPS.findIndex(s => s.id === order.status);
    const safeIndex = currentStepIndex > -1 ? currentStepIndex : 1;

    let stepsHtml = ORDER_STEPS.map((step, idx) => {
      let stepClass = "";
      if (idx < safeIndex) {
        stepClass = "completed";
      } else if (idx === safeIndex) {
        stepClass = "active";
      }

      return `
        <div class="tracking-step ${stepClass}">
          <div class="step-marker">
            ${idx < safeIndex ? '✓' : (idx + 1)}
          </div>
          <div class="step-content">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h5>${step.label}</h5>
              <span style="font-size: 0.75rem; color: var(--gold-accent);">${idx <= safeIndex ? '✓' : step.time}</span>
            </div>
            <p>${step.desc}</p>
          </div>
        </div>
      `;
    }).join("");

    const itemsSummary = order.items.map(i => `
      <div style="display: flex; justify-content: space-between; font-size: 0.85rem; padding: 0.35rem 0; border-bottom: 1px dashed rgba(255,255,255,0.06);">
        <span>${i.quantity}x ${i.name}</span>
        <span style="color: var(--primary-orange); font-weight: 600;">${formatCurrency(i.price * i.quantity)}</span>
      </div>
    `).join("");

    trackingContainer.innerHTML = `
      <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
          <span style="font-size: 0.8rem; color: var(--text-muted);">ORDER NUMBER</span>
          <span class="order-id-badge" style="margin: 0;">#${order.orderId}</span>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">STATUS</div>
            <div style="font-size: 1.05rem; font-weight: 700; color: var(--gold-accent);">${order.status}</div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 0.75rem; color: var(--text-muted);">ESTIMATED TIME</div>
            <div style="font-size: 1.05rem; font-weight: 700; color: var(--primary-orange);">${order.estimatedDeliveryTime}</div>
          </div>
        </div>
      </div>

      <!-- Live Stepper -->
      <div class="tracking-timeline">
        ${stepsHtml}
      </div>

      <!-- Third-Party Delivery Rider Card (Zomato / Swiggy Fleet) -->
      ${(order.shipment && order.shipment.riderName && order.shipment.riderName !== "Not Assigned") ? `
        <div style="background: rgba(255, 107, 0, 0.08); border: 1.5px solid ${order.shipment.partner && order.shipment.partner.toLowerCase().includes('zomato') ? '#cb202d' : order.shipment.partner && order.shipment.partner.toLowerCase().includes('swiggy') ? '#fc8019' : 'var(--gold-accent)'}; border-radius: var(--radius-md); padding: 1.15rem; margin-top: 1.5rem;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.65rem;">
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <span style="font-size: 1.5rem;">🛵</span>
              <div>
                <div style="font-size: 0.72rem; color: var(--text-muted); font-weight: 800; text-transform: uppercase;">
                  ${order.shipment.partner || '3rd-Party Delivery Partner'}
                </div>
                <div style="font-size: 1.05rem; font-weight: 800; color: #fff;">
                  ${order.shipment.riderName}
                </div>
              </div>
            </div>
            <span style="background: ${order.shipment.partner && order.shipment.partner.toLowerCase().includes('zomato') ? 'rgba(203, 32, 45, 0.25)' : 'rgba(252, 128, 25, 0.25)'}; color: ${order.shipment.partner && order.shipment.partner.toLowerCase().includes('zomato') ? '#ff6b77' : '#ffa959'}; font-size: 0.75rem; padding: 0.25rem 0.65rem; border-radius: 4px; font-weight: 800;">
              CONNECTED • ${order.shipment.rating || '4.9★'}
            </span>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; font-size: 0.82rem; color: var(--text-secondary); margin-bottom: 0.85rem;">
            <div>🏍️ <strong>Vehicle:</strong> ${order.shipment.vehicleNo || 'Bike'}</div>
            <div>⏱️ <strong>ETA:</strong> ${order.estimatedDeliveryTime || '25 mins'}</div>
          </div>

          <div style="display: flex; gap: 0.5rem;">
            <a href="tel:${order.shipment.riderPhone}" class="btn-primary" style="flex: 1; justify-content: center; font-size: 0.85rem; padding: 0.55rem; text-decoration: none;">
              📞 Call Rider
            </a>
            <a href="https://wa.me/91${(order.shipment.riderPhone || '').replace(/\D/g, '')}?text=Hi%20${encodeURIComponent(order.shipment.riderName)},%20I%20am%20the%20customer%20for%20Spice%20Street%20Order%20%23${order.orderId}" target="_blank" class="btn-contact btn-whatsapp" style="flex: 1; justify-content: center; font-size: 0.85rem; padding: 0.55rem; text-decoration: none;">
              💬 WhatsApp Rider
            </a>
          </div>
        </div>
      ` : ''}

      <!-- Delivery Details Card -->
      <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 1.25rem; margin-top: 1rem;">
        <h4 style="font-size: 0.95rem; margin-bottom: 0.75rem; color: var(--gold-accent);">📍 Delivery Address</h4>
        <p style="font-size: 0.88rem; font-weight: 600;">${order.customer.fullName} (${order.customer.phone})</p>
        <p style="font-size: 0.82rem; color: var(--text-secondary); margin-top: 0.2rem;">
          ${order.customer.address.flatNo}, ${order.customer.address.street}, ${order.customer.address.city} - ${order.customer.address.pincode}
        </p>
        ${order.customer.deliveryInstructions ? `<p style="font-size: 0.78rem; color: var(--text-dim); margin-top: 0.4rem;"><em>Note: ${order.customer.deliveryInstructions}</em></p>` : ''}
      </div>

      <!-- Items Breakdown -->
      <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 1.25rem; margin-top: 1rem;">
        <h4 style="font-size: 0.95rem; margin-bottom: 0.75rem; color: var(--gold-accent);">🍛 Ordered Food (${order.items.length} items)</h4>
        <div>${itemsSummary}</div>
        <div style="display: flex; justify-content: space-between; font-weight: 800; font-size: 1.05rem; margin-top: 0.75rem; padding-top: 0.5rem; border-top: 1px solid var(--border-subtle);">
          <span>Total Paid (${order.payment.method.toUpperCase()})</span>
          <span style="color: var(--gold-accent);">${formatCurrency(order.pricing.grandTotal)}</span>
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display: flex; gap: 0.75rem; margin-top: 1.5rem;">
        <button class="btn-primary" style="flex: 1; justify-content: center;" onclick="openWhatsAppOrderUpdate('${order.orderId}')">
          💬 WhatsApp Live Help
        </button>
        <button class="btn-outline" style="flex: 1; justify-content: center;" onclick="closeAllModals()">
          Done
        </button>
      </div>
    `;
  }
}

window.trackingController = new TrackingController();
